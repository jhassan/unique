<?php include_once("header1.php"); ?>

    <!-- Page Content -->
    <div class="container" style="margin-top:70px;">
        <!-- Image Header -->
        <div class="row">
            <div class="col-lg-12" style="margin-top:51px;">
                <img class="img-responsive" src="../images/toursbanner.jpg" alt="Services">
            </div>
        </div>
        <!-- Page Heading/Breadcrumbs -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Our
                    <small>Services</small>
                </h1>
            </div>
        </div>
        <!-- /.row -->
        <!-- Content Column -->
        <div class="row">
            <div class="col-md-12">
                <p>Our services include everything related Travel & Tourism such as:</p>
                <p>Domestic &International Airline Reservation & Ticketing.</p>
                <ul>
                <li>Worldwide Hotel Reservation.</li>
                <li>Worldwide Car Rental</li>                                       
                <li>Ziarat of Holy Placed (Iraq & Iran)</li>                                                   
                <li>Umrah Incentive & Special Groups.</li>
                <li>Hajj Services</li>
                <li>International Tour Packages</li>
                <li>Domestic Tours</li>
                <li>Visit visa processing services</li>
                <li>Honeymoon Packages</li>
                <ul>
            </div>
        </div>    
        <?php include_once("footer.php"); ?>