<?php
	// Log Type
	$arrLogType[] = "Select Type"; // 0
    $arrLogType[] = "Client Login"; // 2
    $arrLogType[] = "Client Logout"; // 3
    $arrLogType[] = "Create Ticket"; // 4

    // Page Permission
    $PagePermission = array(
    	'daily_sale.php' => 64
    );
?>