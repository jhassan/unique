html>
<body onload="document.createElement('form').submit.call(document.getElementById('myForm'))">
<form id="myForm" name="myForm" action="http://eticket.shaheenair.com/login.php?code=2" method="POST">
<input type=hidden name="uname" id="uname" value="euniquetravels"/>
<input type=hidden name="upass" id="upass" value="786k"/>
<input type=hidden name="submit" id="submit" value="Continue"/>
</form>
</body>
</html>