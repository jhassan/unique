<?php include_once("header.php"); ?>
<div class="main">
  <div class="content">
    <div class="container_12">
      <div class="grid_12">
        <h3 class="head1">Our Mission</h3>
        <p class="text1 tx2">“Fulfill your Travel Desires is our Mission. We want to give our clients a unique Platform having one click Travel solutions. Our Professional team’s first hand knowledge is ready to helps you make the right Travel decision. A dynamic effort of our diligent professionals and the valuable support from our respected customers has helped us to grow. It’s our aim to entertain our honorable clients with new technologies, inventions and facilities of the great travel industry”.</p>
        <div class="clear"></div>
      </div>
      <div class="clear"></div>
    </div>
  </div>
  <?php include_once("footer.php"); ?>