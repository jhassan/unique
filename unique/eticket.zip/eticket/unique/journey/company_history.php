<?php include_once("header.php"); ?>
<div class="main">
  <div class="content">
    <div class="container_12">
      <div class="grid_12">
        <h3 class="head1">Company History</h3>
        <p class="text1 tx2">Unique Travel & Tours was started by Mr. Ibrahim Ishaq (MD) in 2013, on his own without any help. He took this bold step and entered into travel industry as travel consultant. In 2014 Unique Travel & Tours were incorporated as put lied with 3 employees and few corporate clients like Subhanallah Estate, Malik Brothers, Unique Wires etc. We delivered 100% what we promised at competitive fares and become trustworthy. We start our career with Shaheen Air to serve our clients best air fares in Asian Countries. On giving the Convenient Services to our clients our business grown well and we started to entertain our corporate clients with other airlines include Air Blue and Pakistan International Airline.</p>
        <p class="text1 tx2">In 2016 we felt a need of international airlines selling so we get accredited with  International Air Transport Association Passenger Sales Agent License and now we are serving our Clients with all BSP Airlines. In 2014 we started Umrah for our corporate clients and partner companies to give them easy access and comfort ability in their religious obligations.</p>
        <p class="text1 tx2">In these Present Days we feel proud to share  this information to you so that we could build our self as a complete channel which has become one of the largest service providers in Pakistan for all kind of tour packages, accommodations, hospitality, umrah packages, Hajj packages and non-stop travelling solutions.</p>
        <p class="text1 tx2">We started our company from Lahore and by the Grace of Allah Almighty now Unique Travel and Tours is fully functional in 6 Major cities of Pakistan include Islamabad, Multan, Burewala, Sheikhupura, Peshawar & Kasur.</p>
        <div class="clear"></div>
      </div>
      <div class="clear"></div>
    </div>
  </div>
  <?php include_once("footer.php"); ?>