<?php include_once("header.php"); ?>
<div class="main">
  <div class="content">
    <div class="container_12">
      <div class="grid_12">
        <h3 class="head1">CEO Message</h3>
        <p class="text1 tx2">Chaudary Umair Mushtaq (C.E.O)</p>
        <p class="text1 tx2">“Message”</p>
        <p class="text1 tx2">“I am truly excited to join this terrific business. Since we started Unique Travel & Tours in 2013, we set out to help consumers feel their best by providing convenient, affordable and high standard services, which was something no one else was doing. Our task is to help clients define their problems and then solve them together. This process involves not only the high professional team and also the moral commitment of Unique Travel & Tours. Because it is the clients' trust that promotes the reputation of Unique Travel & Tours”.</p>
        <div class="clear"></div>
      </div>
      <div class="clear"></div>
    </div>
  </div>
  <?php include_once("footer.php"); ?>