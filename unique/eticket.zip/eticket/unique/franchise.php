<?php include_once("header2.php"); ?>
<div class="main">
  <div class="content">
    <div class="container_12">
      <div class="grid_12">
        <h3>Franchises</h3>
        <div class="tours">
          <div class="grid_4 alpha">
            <div class="tour"> <img src="images/global.jpg" alt="" class="img_inner fleft">
              <div class="clear"></div>
              <div class="extra_wrapper">
                <p class="text1">Global Link Air Islamabad</p>
              </div>
            </div>
          </div>
          <div class="grid_3 alpha">
            <div class="tour"> <img src="images/mct.jpg" alt="" class="img_inner fleft">
              <div class="clear"></div>
              <div class="extra_wrapper">
                <p class="text1">Mian Channu Travels</p>
              </div>
            </div>
          </div>
          <div class="grid_4 omega">
            <div class="tour"> <img src="images/mux.jpg" alt="" class="img_inner fleft">
              <div class="clear"></div>
              <div class="extra_wrapper">
                <p class="text1">MUX Aviation Multan</p>
              </div>
            </div>
          </div>
          <div class="clear"></div>
        </div>
      </div>
      <div class="clear"></div>
    </div>
  </div>
  <?php include_once("footer.php"); ?>