<?php include_once("header2.php"); ?>
<link rel="stylesheet" href="css/lightbox.min.css">
<div class="main">
  <div class="content">
    <div class="container_12">
      <div class="grid_12">
        <h3>Our Gallery</h3>
      </div>
      <div class="clear"></div>
      <div class="gallery">
        <div class="grid_4"> 
          <a class="example-image-link" href="images/1.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/s1.jpg" alt=""/></a>
          <a class="example-image-link hide" href="images/2.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/s2.jpg" alt="" /></a>
          <a class="example-image-link hide" href="images/3.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/s3.jpg" alt="" /></a>
          <a class="example-image-link hide" href="images/4.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/s4.jpg" alt="" /></a>
          <a class="example-image-link hide" href="images/5.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/s5.jpg" alt="" /></a>
          <a class="example-image-link hide" href="images/6.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/s6.jpg" alt="" /></a>
          <a class="example-image-link hide" href="images/7.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/s7.jpg" alt="" /></a>
          <a class="example-image-link hide" href="images/8.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/s8.jpg" alt="" /></a>
          <a class="example-image-link hide" href="images/9.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/s9.jpg" alt="" /></a>



          <!-- <a href="images/1.jpg" class="gal img_inner"><img src="images/s1.jpg" alt=""></a>  -->
        </div>
        <!-- <div class="grid_4"> <a href="images/2.jpg" class="gal img_inner"><img src="images/s2.jpg" alt=""></a> </div>
        <div class="grid_4"> <a href="images/3.jpg" class="gal img_inner"><img src="images/s3.jpg" alt=""></a> </div>
        <div class="clear"></div>
        <div class="grid_4"> <a href="images/4.jpg" class="gal img_inner"><img src="images/s4.jpg" alt=""></a> </div>
        <div class="grid_4"> <a href="images/5.jpg" class="gal img_inner"><img src="images/s5.jpg" alt=""></a> </div>
        <div class="grid_4"> <a href="images/6.jpg" class="gal img_inner"><img src="images/s6.jpg" alt=""></a> </div>
        <div class="clear"></div>
        <div class="grid_4"> <a href="images/7.jpg" class="gal img_inner"><img src="images/s7.jpg" alt=""></a> </div>
        <div class="grid_4"> <a href="images/8.jpg" class="gal img_inner"><img src="images/s8.jpg" alt=""></a> </div>
        <div class="grid_4"> <a href="images/9.jpg" class="gal img_inner"><img src="images/s9.jpg" alt=""></a> </div> -->
      </div>
      <div class="clear"></div>
    </div>
  </div>
  <script src="js/lightbox-plus-jquery.min.js"></script>
  <?php include_once("footer.php"); ?>