


 <form method='post' action='http://vagent.piac.aero/Security/SignIn.aspx?ReturnUrl=%2f'>
 <div>
             Username: <input class='tbox' type='text'     name='username' size='15' value='uttbook' maxlength='20' />&nbsp;&nbsp;
             Password: <input class='tbox' type='password' name='userpass' size='15' value='unique1234' maxlength='20' />&nbsp;&nbsp;
             <input type='hidden' name='autologin' value='1' />
             <input class='button' type='submit' name='userlogin' value='Login' />
 </div>
 </form>
