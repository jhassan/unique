<!DOCTYPE html>
<html lang="en">
<head>
<title>Journey | Blog</title>
<meta charset="utf-8">
<link rel="icon" href="images/favicon.ico">
<link rel="shortcut icon" href="images/favicon.ico">
<link rel="stylesheet" href="css/style.css">
<script src="js/jquery.js"></script>
<script src="js/jquery-migrate-1.1.1.js"></script>
<script src="js/superfish.js"></script>
<script src="js/jquery.equalheights.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.ui.totop.js"></script>
<script>
$(window).load(function () {
    $().UItoTop({
        easingType: 'easeOutQuart'
    });
});
</script>
<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<link rel="stylesheet" media="screen" href="css/ie.css">
<![endif]-->
</head>
<body>
<header>
  <div class="container_12">
    <div class="grid_12">
      <h1><a href="index.html"><img src="images/logo.png" alt=""></a></h1>
      <div class="clear"></div>
    </div>
    <div class="menu_block">
      <nav>
        <ul class="sf-menu">
          <li><a href="index.html">Home</a></li>
          <li><a href="about.html">About</a>
            <ul>
              <li><a href="#">Agency</a></li>
              <li><a href="#">News</a></li>
              <li><a href="#">Team</a></li>
            </ul>
          </li>
          <li><a href="gallery.html">Gallery</a></li>
          <li><a href="tours.html">Tours</a></li>
          <li class="current"><a href="blog.html">Blog</a></li>
          <li><a href="contacts.html">Contacts</a></li>
        </ul>
      </nav>
      <div class="clear"></div>
    </div>
    <div class="clear"></div>
  </div>
</header>
<div class="main">
  <div class="content">
    <div class="container_12">
      <div class="grid_9">
        <h3>Recent Posts</h3>
        <div class="blog">
          <time datetime="2045-01-01">23<br>
            APR</time>
          <div class="extra_wrapper">
            <div class="text1 upp">Dellentesq imperdir gerti </div>
            <div class="links">Posted by <a href="#">Demo User</a><a href="#" class="comment">0 Comment(s)</a></div>
          </div>
          <div class="clear"></div>
          <img src="images/page5_img1.jpg" alt="" class="img_inner fleft">
          <div class="extra_wrapper">
            <p class="text1">Gellentesque imperdiet gerti loki holewvelit neque. Ut vestibulum mi sit amet ornare. </p>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse jew wligulawe dolor, condimentum ac justo sed, tincidunt commodo molity wer massarete. Nulla non urnatr nisi. Donec varius lectus in vestibulum auctor. Spendisse magna veliternowe dignissim eu commodo ut vestibulum nectro quam. Pellentesque imperdiet velit neque. Ut vestibulum mi sit ametwertilo ornare consectetur. Quisque sed quamhy loi justo. Nulla congue sed turpis nec lacinia. Nulla facilisi. Ut sit amet gravidatylo wtellus. Morbi id wer nolit consequat eros. </p>
            Vivamus imperdiet ante vitae lorem varius tristique meli. Phasellus tristique lectus id volutpat condimentum. Mauris quam lectus cursus at congue nec ultrices luctus orci quam lectus cursus at congue. <br>
            <a href="#" class="btn">Details</a> </div>
        </div>
        <div class="blog">
          <time datetime="2045-01-01">23<br>
            APR</time>
          <div class="extra_wrapper">
            <div class="text1 upp">Dellentesq imperdir gerti </div>
            <div class="links">Posted by <a href="#">Demo User</a><a href="#" class="comment">0 Comment(s)</a></div>
          </div>
          <div class="clear"></div>
          <img src="images/page5_img2.jpg" alt="" class="img_inner fleft">
          <div class="extra_wrapper">
            <p class="text1">Gellentesque imperdiet gerti loki holewvelit neque. Ut vestibulum mi sit amet ornare. </p>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse jew wligulawe dolor, condimentum ac justo sed, tincidunt commodo molity wer massarete. Nulla non urnatr nisi. Donec varius lectus in vestibulum auctor. Spendisse magna veliternowe dignissim eu commodo ut vestibulum nectro quam. Pellentesque imperdiet velit neque. Ut vestibulum mi sit ametwertilo ornare consectetur. Quisque sed quamhy loi justo. Nulla congue sed turpis nec lacinia. Nulla facilisi. Ut sit amet gravidatylo wtellus. Morbi id wer nolit consequat eros. </p>
            Vivamus imperdiet ante vitae lorem varius tristique meli. Phasellus tristique lectus id volutpat condimentum. Mauris quam lectus cursus at congue nec ultrices luctus orci quam lectus cursus at congue. <br>
            <a href="#" class="btn">Details</a> </div>
        </div>
      </div>
      <div class="grid_3">
        <h3>Categories</h3>
        <ul class="list2 l1">
          <li><a href="#">Fgo psu dr sit amek </a></li>
          <li><a href="#">Sem psum dr sit ametre conse </a></li>
          <li><a href="#">Rame sum dr sit ame consec</a></li>
          <li><a href="#">Bem psum dr sit ameteko </a></li>
          <li><a href="#">Nem dsum dr sit amewas </a></li>
          <li><a href="#">Vcem psum dr sit </a></li>
        </ul>
        <h3>Archive</h3>
        <ul class="list2 l1">
          <li><a href="#">August 2045</a></li>
          <li><a href="#">July 2045</a></li>
          <li><a href="#">June 2045</a></li>
          <li><a href="#">May 2045</a></li>
          <li><a href="#">April 2045</a></li>
          <li><a href="#">March 2045</a></li>
          <li><a href="#">February 2045</a></li>
          <li><a href="#">January 2045</a></li>
          <li><a href="#">December 2011</a></li>
        </ul>
      </div>
      <div class="clear"></div>
    </div>
  </div>
  <div class="bottom_block">
    <div class="container_12">
      <div class="grid_2 prefix_2">
        <ul>
          <li><a href="#">FAQS Page</a></li>
          <li><a href="#">People Say</a></li>
        </ul>
      </div>
      <div class="grid_2">
        <ul>
          <li><a href="#">Useful links</a></li>
          <li><a href="#">Partners</a></li>
        </ul>
      </div>
      <div class="grid_2">
        <ul>
          <li><a href="#">Insurance</a></li>
          <li><a href="#">Family Travel</a></li>
        </ul>
      </div>
      <div class="grid_2">
        <h4>Contact Us:</h4>
        TEL: 1-800-234-5678<br>
        <a href="#">info@demolink.org</a> </div>
      <div class="clear"></div>
    </div>
  </div>
</div>
<footer>
  <div class="container_12">
    <div class="grid_12">
      <div class="socials"> <a href="#"></a> <a href="#"></a> <a href="#"></a> <a href="#"></a> </div>
      <div class="copy"> Journey &copy; 2045 | <a href="#">Privacy Policy</a> | Design by: <a href="http://www.templatemonster.com/">TemplateMonster.com</a> </div>
    </div>
    <div class="clear"></div>
  </div>
</footer>
</body>
</html>